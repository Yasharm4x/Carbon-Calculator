import { MLEmissionsCalculator } from "@/components/MLEmissionsCalculator";

const Index = () => {
  return <MLEmissionsCalculator />;
};

export default Index;
